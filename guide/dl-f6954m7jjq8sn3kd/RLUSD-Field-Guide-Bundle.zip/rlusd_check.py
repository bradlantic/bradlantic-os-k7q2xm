#!/usr/bin/env python3
"""RLUSD supply check. Free, read-only, no keys, no wallet.
Reads RLUSD supply straight from public nodes:
  XRPL:     gateway_balances on issuer rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De
  Ethereum: totalSupply() on proxy 0x8292bb45bf1ee4d140127049757c2e0ff06317ed
  Base:     totalSupply() on proxy 0x8d58c0c60b8d6b88fa98b291a646db34d0f98258
Addresses from https://docs.ripple.com/products/stablecoin/overview/token-addresses
Run: python3 rlusd_check.py   (Python 3.8+, standard library only)
"""
import json, urllib.request, datetime

def post(url, body):
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "User-Agent": "rlusd-check"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)

def xrpl_supply():
    d = post("https://xrplcluster.com/", {"method": "gateway_balances", "params": [{
        "account": "rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De", "ledger_index": "validated"}]})
    return float(d["result"]["obligations"]["524C555344000000000000000000000000000000"])

def evm_supply(rpc, contract):
    d = post(rpc, {"jsonrpc": "2.0", "id": 1, "method": "eth_call",
                   "params": [{"to": contract, "data": "0x18160ddd"}, "latest"]})
    return int(d["result"], 16) / 1e18  # RLUSD uses 18 decimals

rows = []
for name, fn in [
    ("XRP Ledger", xrpl_supply),
    ("Ethereum", lambda: evm_supply("https://ethereum-rpc.publicnode.com", "0x8292bb45bf1ee4d140127049757c2e0ff06317ed")),
    ("Base", lambda: evm_supply("https://base-rpc.publicnode.com", "0x8d58c0c60b8d6b88fa98b291a646db34d0f98258")),
]:
    try:
        rows.append((name, fn()))
    except Exception as e:
        print(f"{name}: could not read ({e})")

total = sum(v for _, v in rows)
print("RLUSD supply check,", datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
for name, v in rows:
    print(f"  {name:<11} {v/1e6:>10,.1f}M  {v/total*100:5.1f}%")
print(f"  {'Total':<11} {total/1e6:>10,.1f}M  (chains read above only)")
